from django.contrib import admin
from .models import student_marks_detials,student_result
# Register your models here.

admin.site.register(student_marks_detials)
admin.site.register(student_result)
