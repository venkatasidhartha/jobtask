from rest_framework import serializers
from .models import student_marks_detials,student_result

class student_detial_serial(serializers.ModelSerializer):
    class Meta:
        model = student_marks_detials
        fields = ['id','Name','Roll_Number','D_O_B','Marks','Grade']


class stident_result_serial(serializers.ModelSerializer):
    class Meta:
        model = student_result
        fields = ['id','Name','Roll_Number','D_O_B','Marks','Grade','Passed_with']



