from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import student_detial_view, studenr_result_view

router = DefaultRouter()
router.register('add-mark',student_detial_view,basename="add-mark")
router.register("results",studenr_result_view,basename="results")


urlpatterns = [
    path('student/',include(router.urls))
]