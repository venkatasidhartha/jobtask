from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.response import Response
import requests
from collections import Counter
from .serilization import student_detial_serial, stident_result_serial
from .models import student_marks_detials, student_result
# Create your views here.


class student_detial_view(viewsets.ModelViewSet):
    serializer_class = student_detial_serial
    queryset = student_marks_detials.objects.all()

    def create(self, request, *args, **kwargs):
       data = request.POST
       last_roll_num = len(student_marks_detials.objects.all())
       Name = data["Name"]
       Roll_Number = "TKS"+str(int(last_roll_num + 1))
       D_O_B = data["D_O_B"]
       Marks = int(data["Marks"])

       Grade = ''
       if Marks >= 91 and Marks <= 100:
           Grade = "A"
       elif Marks >= 81 and Marks <= 90:
           Grade = "B"
       elif Marks >= 71 and Marks <= 80:
           Grade = "C"
       elif Marks >= 61 and Marks <= 70:
           Grade = "D"
       elif Marks >= 55 and Marks <= 61:
           Grade = "E"
       elif Marks < 55:
           Grade = "F"
       db_save = student_marks_detials.objects.create(Name=Name, Roll_Number=Roll_Number, D_O_B=D_O_B, Marks=Marks,Grade=Grade)
       db_save.save()
       print(student_detial_serial(db_save).data)
       return Response(student_detial_serial(db_save).data)


class studenr_result_view(viewsets.ModelViewSet):
    serializer_class = stident_result_serial
    http_method_names = ['get']

    def get_queryset(self):
        json_data = requests.get('http://127.0.0.1:8080/api/student/add-mark/').json()
        if len(json_data) > len(student_result.objects.all()):
            total_students = len(json_data)
            insert_data = int(len(json_data) - len(student_result.objects.all()))
            arr = []
            for i in json_data[-int(insert_data):]:
                arr.append(i["Grade"])
            count_data = dict(Counter(arr))
            distinction = count_data["A"]/total_students
            first_class = count_data["B"] + count_data["C"]/total_students
            pass_ = total_students - count_data["F"] / total_students

            for j in json_data[-int(insert_data):]:
                Name = j["Name"]
                Roll_Number = j["Roll_Number"]
                D_O_B = j["D_O_B"]
                Marks = j["Marks"]
                Grade = j["Grade"]
                Passed_with = ''
                if Grade == "A":
                    Passed_with = "Passed With Distinction "+str(distinction)+" %"
                elif Grade == "B" or Grade == "C":
                    Passed_with = "Passed With First_class " + str(first_class)+" %"
                elif Grade == "D" or Grade == "E":
                    Passed_with = "Passed With Pass " + str(pass_)+" %"
                elif Grade == "F":
                    Passed_with = ""
                ins_db_data = student_result.objects.create(Name=Name,Roll_Number=Roll_Number,D_O_B=D_O_B,Marks=Marks,Grade=Grade,Passed_with=Passed_with)
                ins_db_data.save()

        return student_result.objects.all()






