from django.db import models

# Create your models here.


class student_marks_detials(models.Model):
    Name = models.CharField(max_length=100)
    Roll_Number = models.CharField(max_length=100)
    D_O_B = models.DateField()
    Marks = models.CharField(max_length=100)
    Grade = models.CharField(max_length=100)


class student_result(models.Model):
    Name = models.CharField(max_length=100)
    Roll_Number = models.CharField(max_length=100)
    D_O_B = models.DateField()
    Marks = models.CharField(max_length=100)
    Grade = models.CharField(max_length=100)
    Passed_with = models.CharField(max_length=100)


